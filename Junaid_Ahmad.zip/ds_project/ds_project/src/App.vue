<template>
  <!-- <nav>
    <router-link to="/">Home</router-link> |
    <router-link to="/about">About</router-link>
  </nav> -->
  <router-view />
</template>

<style>
#app {
    font-family: "Times New Roman", Times, serif;
  text-align: center;
    font-weight: 16px;
}
#main {
  font-family: "Times New Roman", Times, serif;
  font-weight: 16px;
}
</style>
